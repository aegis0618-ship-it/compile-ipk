# OpenWrt Console APK

这是 OpenWrt 25.12 的 APK 软件包源码，不是 Android APK。

## GitHub Actions 云编译

1. 将本目录内容上传到 GitHub 仓库根目录（需要包含隐藏目录 `.github`）。
2. 打开仓库的 **Actions** 页面并启用 Actions。
3. 选择 **Build OpenWrt Console APK**，点击 **Run workflow**。
4. 输入与路由器完全一致的 OpenWrt 版本和 target/subtarget。x86_64 常见值为 `x86` / `64`。
5. 运行结束后打开该次工作流，在 **Artifacts** 下载 `openwrt-console-...` 压缩包。
6. 从压缩包中取出 `.apk` 文件并上传到路由器。

工作流默认使用 OpenWrt `25.12.6`、`x86/64`。设备若为 Snapshot 或其他正式版本，应将 SDK 版本改为设备对应版本。可在设备上查看：

```sh
ubus call system board
apk --print-arch
```

APK 应与设备 target/subtarget 和发行版本匹配；不要把 x86/64 的包安装到 ARM 或其他 target。

## 构建

也可以将本目录复制到 OpenWrt SDK 的 `package/` 目录，例如：

```sh
cp -r openwrt-console package/
make defconfig
make package/openwrt-console/compile V=s
```

生成的包位于：

```text
bin/packages/*/base/openwrt-console_1.0.0-1_all.apk
```

## 安装

将生成的 APK 上传到设备后执行：

```sh
apk add --allow-untrusted /tmp/openwrt-console_1.0.0-1_all.apk
```

安装完成后运行：

```sh
/usr/sbin/openwrt-console
```

本软件包默认不会修改 `/etc/profile`，不会自动接管 SSH 登录，也不会自动重启设备。
